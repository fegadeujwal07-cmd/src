#ifndef ZONE_MANAGER__POST_REPLAN_HPP_
#define ZONE_MANAGER__POST_REPLAN_HPP_

#include <chrono>
#include <string>
#include <unordered_set>
#include <vector>

namespace zone_manager
{

/// Fingerprint of a robot plan used to detect post-replan updates.
struct PlanSnapshot
{
  std::string current_zone;
  std::vector<std::string> next_zones;
  std::vector<std::string> zone_sequence;
  std::vector<std::string> planned_path;
};

/// Armed wait after /replan_candidate until a new MonitoredTaskDetails plan arrives.
struct PendingReplanWatch
{
  std::string zone_id;
  std::string candidate_robot_id;
  std::vector<std::string> conflicting_robots;
  PlanSnapshot snapshot_at_arm;
  std::chrono::steady_clock::time_point armed_at{};
};

/// True if `incoming` has a usable plan and differs from `baseline`.
bool is_new_plan_for_candidate(
  const PlanSnapshot & baseline,
  const PlanSnapshot & incoming);

/// Conflicting robots that should be resumed (not in the new pause set).
std::vector<std::string> robots_to_resume(
  const std::vector<std::string> & conflicting_robots,
  const std::vector<std::string> & pause_robot_ids);

/// True when watch age exceeds timeout_sec (timeout_sec <= 0 disables).
bool is_replan_watch_timed_out(
  const PendingReplanWatch & watch,
  std::chrono::steady_clock::time_point now,
  double timeout_sec);

}  // namespace zone_manager

#endif  // ZONE_MANAGER__POST_REPLAN_HPP_
